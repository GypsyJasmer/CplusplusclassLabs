#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void draw_triangle(char char_out, int width, int length);
void draw_square(char char_out, int width, int length);
void draw_diamond(char char_out, int width, int length);
void draw_rectangle(char char_out, int length);


int main()
{
    char 'T', 'S', 'D', 'R';

cout << "What shape do you want to draw? /n"
        "'T' for triangle, 'S' for square, /n"
        "'D' for diamond, and 'R' for rectangle." << endl;

    //enter data validation with TOUPPER

   ifstream infile;

   infile.open("infile.txt");

   ofstream outfile;

   outfile.open("output.txt");

   if (!infile.good())
   {
       cout << "Program failed to open correctly"<< endl;
   }
   else
   {
       string buffer;
       //see notes
       while(!infile.eof())
       {
           getline((infile, buffer);
           cout << buffer << endl;
       }

   }
   return 0;

}

void draw_triangle(char char_out, int width, int length)
{
    /* if code is for a TRIANGLE
    read num1 from infile.dat
    draw a triangle using out_char*/
}
void draw_square(char char_out, int width, int length)
void draw_diamond(char char_out, int width, int length)
void draw_rectangle(char char_out, int length)
{
    /* if code is for a RECT
    read num1 and num2 from infile.dat
    draw a rectangle using out_char
    */
}

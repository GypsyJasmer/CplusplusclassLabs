#ifndef DEALER_H_INCLUDED
#define DEALER_H_INCLUDED

class Dealer{
    private:
    public:


};

#endif // DEALER_H_INCLUDED

 //returns the low score of the hand

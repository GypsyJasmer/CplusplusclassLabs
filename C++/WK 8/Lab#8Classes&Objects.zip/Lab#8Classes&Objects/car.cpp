#include <iostream>

using namespace std;

/**************************************
input is make, color, year. Creates a new car,
creates a new link that points to that car,adds
the link to the head of the list
**************************************/
void addCar()
{

}


/**************************************
input is make, color, year. Creates a temporary car with those inputs. Uses the
overloaded equality operator to check the list to see if such a car exists. Returns true if found, false
otherwise
**************************************/
void findCar()
{

}

 /**************************************
if list is empty, returns nullptr. Otherwise returns a pointer to the car at the head
of the list and deletes that struct
**************************************/
void removeHead()
{

}

 /**************************************
return a string containing the Cars in the list. Use the overloaded << operator to
create this list. There should be a comma and space after each car.
**************************************/
void displayList()
{

}

#ifndef CAR_H_INCLUDED
#define CAR_H_INCLUDED

#include <string>

/*Your car class should have the following:
default constructor that sets up a 1910, Black, Ford
overloaded constructor that takes a string color, string color, and integer year
setters and getters for all three variables

a link struct that contains a pointer to next and a pointer to a car object
constructor that sets head to nullptr
a destructor that walks down the list and deletes any remaining links*/

/* code for class
int Car::counter = 0;
Car* Car::cars[Car::SIZE];

Car::Car(string model, string color)
{
    this->model = model;
    this->color = color;

    cars[counter] = this;
    counter++;
}
Car::Car()
{
    model = "Ford";
    color = "Black";

    cars[counter] = this;
    counter++;
}*/

class Car{
    int year;
    std::string color;
    std::string model;
    const carYear=1910; //const in classes? global or local?

public:
    //overloaded constructor required
    //Overloaded << operator that adds year, color, make to the provided output stream
    Car(int year=1910, std::string color="Black", std::string model="Ford") {year=vehYear; color=c; model=m;}


    //mutator
    void setYear (int vehYear) {year=vehYear;}
    void setColor(std::string c) {color=c;}
    void setModel(std::string m) {model=m;}

    //accessor
    int getYear() {return year;}
    std::string getColor() {return color;}
    std::string getModel() {return model;}

    //other methods

    //input is color, color, year. Creates a new car, creates a new link that points to that car,adds the link to the head of the list
    void addCar(int year, string color, string model);
    void findCar();
    void removeHead();
    void displayList();




};



#endif // CAR_H_INCLUDED
